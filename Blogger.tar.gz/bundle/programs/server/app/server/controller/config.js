(function(){/*ServiceConfiguration.configurations.upsert(
    { service: "github" },
    {
        $set: {
            clientId: "b8b25b9bfd1afa51e28e",
            loginStyle: "popup",
            secret: "fab5179d13adadb0875a6abd881a4e50fc265108"
        }
    }
);*/



/*ServiceConfiguration.configurations.upsert(
    { service: "google" },
    {
        $set: {
            appId: "443029820215-es7u5mmn3rgv595no9ms7hgd9bga9tvc.apps.googleusercontent.com",
            loginStyle: "popup",
            secret: "RmT5JjrvagMXFXI_cxx_C9B9"
        }
    }
);*/


ServiceConfiguration.configurations.upsert(
    {service: "facebook" },
    {
        $set: {
            appId: "1586224008257036",
            loginStyle: "popup",
            secret: "b44d3e6bd3ef9348ddf203a302f3fa90"
        }
    }
);


})();
