(function(){/*
Schemas = {};

Schemas.User = new SimpleSchema({
    emails: {
        type: [Object],
        // this must be optional if you also use other login services like facebook,
        // but if you use only accounts-password, then it can be required
        optional: false
/*
    },
    "emails.$.address": {
        type: String,
        regEx: SimpleSchema.RegEx.Email
    },
    "emails.$.verified": {
        type: Boolean
    },
    created_at: {
        type: String,
        optional:true
    },

    username:{
        type:String,
        optional:true
    }


});
*/



/*Meteor.users.attachSchema(Schemas.User);*/

})();
