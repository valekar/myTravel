(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['okgrow:iron-router-autoscroll'] = {};

})();

//# sourceMappingURL=okgrow_iron-router-autoscroll.js.map
