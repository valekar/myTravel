(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var isCursor, getCursorCollectionName, deepCopy, Dependency, BaseCollection, CollectionItem, SingleCollectionCallbacksWrapper, CursorWrapper, CallbacksWrapper, getWrappersFromCallbackResult;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/mrt:smart-publish/utils.js                                                                         //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
isCursor = function (c) {                                                                                      // 1
  return c && c._publishCursor;                                                                                // 2
};                                                                                                             // 3
                                                                                                               // 4
getCursorCollectionName = function(c) {                                                                        // 5
  if (!c._cursorDescription) {                                                                                 // 6
    throw new Meteor.Error("Unable to get cursor's collection name");                                          // 7
  }                                                                                                            // 8
  var name = c._cursorDescription.collectionName;                                                              // 9
  if (!name) {                                                                                                 // 10
    throw new Meteor.Error("Unable to get cursor's collection name");                                          // 11
  }                                                                                                            // 12
  return name;                                                                                                 // 13
}                                                                                                              // 14
                                                                                                               // 15
deepCopy = function(value) {                                                                                   // 16
  return EJSON.clone(value);                                                                                   // 17
}                                                                                                              // 18
                                                                                                               // 19
Dependency = function(callback) {                                                                              // 20
  this.callback = callback;                                                                                    // 21
  this.id = Random.id();                                                                                       // 22
}                                                                                                              // 23
                                                                                                               // 24
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/mrt:smart-publish/collection-items.js                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
BaseCollection = function(name) {                                                                              // 1
  this.name = name;                                                                                            // 2
  this.relations = {};                                                                                         // 3
  this.items = {};                                                                                             // 4
}                                                                                                              // 5
BaseCollection.prototype.smartAdded = function(dependencyCursorId, id, fields) {                               // 6
  var items = this.items;                                                                                      // 7
  if (!items[id]) {                                                                                            // 8
    items[id] = new CollectionItem(id, this, fields, dependencyCursorId);                                      // 9
    items[id].updateChildren(this.relations);                                                                  // 10
    this.publication.added(this.name, id, fields);                                                             // 11
  } else {                                                                                                     // 12
    var itemm = items[id];                                                                                     // 13
    _.each(fields, function(val, key) {                                                                        // 14
      itemm.data[key] = itemm.data[key] || {};                                                                 // 15
      itemm.data[key][dependencyCursorId] = deepCopy(val);                                                     // 16
    });                                                                                                        // 17
    itemm.count++;                                                                                             // 18
    itemm.updateFromData(fields);                                                                              // 19
    itemm.updateChildren(fields);                                                                              // 20
  }                                                                                                            // 21
}                                                                                                              // 22
BaseCollection.prototype.smartChanged = function(dependencyCursorId, id, fields) {                             // 23
  var itemm = this.items[id];                                                                                  // 24
  var data = itemm.data;                                                                                       // 25
  _.each(fields, function(val, key) {                                                                          // 26
    data[key] = data[key] || {};                                                                               // 27
    if (val === undefined) {                                                                                   // 28
      delete data[key][dependencyCursorId];                                                                    // 29
    } else {                                                                                                   // 30
      data[key][dependencyCursorId] = deepCopy(val);                                                           // 31
    }                                                                                                          // 32
  });                                                                                                          // 33
  itemm.updateFromData(fields);                                                                                // 34
  itemm.updateChildren(fields);                                                                                // 35
}                                                                                                              // 36
BaseCollection.prototype.smartRemoved = function(dependencyCursorId, id) {                                     // 37
  var itemm = this.items[id];                                                                                  // 38
  if (!itemm) {                                                                                                // 39
    throw new Meteor.Error("Removing unexisting element '" + id + "' from collection '" + this.name + "'");    // 40
  }                                                                                                            // 41
                                                                                                               // 42
  if (!--itemm.count) { // If reference counter was decremented to zero                                        // 43
    this.publication.removed(this.name, id);                                                                   // 44
    itemm.updateChildren(this.relations, true);                                                                // 45
    delete this.items[id];                                                                                     // 46
  } else {                                                                                                     // 47
    var fields = {};                                                                                           // 48
    _.each(itemm.data, function(vals, key) {                                                                   // 49
      if (dependencyCursorId in vals) {                                                                        // 50
        fields[key] = 1;                                                                                       // 51
        delete vals[dependencyCursorId];                                                                       // 52
      }                                                                                                        // 53
    });                                                                                                        // 54
    itemm.updateFromData(fields);                                                                              // 55
    itemm.updateChildren(fields);                                                                              // 56
  }                                                                                                            // 57
}                                                                                                              // 58
                                                                                                               // 59
CollectionItem = function(id, collection, fields, dependencyCursorId) {                                        // 60
  this.id = id;                                                                                                // 61
  this.collection = collection;                                                                                // 62
  this.count = 1;                                                                                              // 63
  this.data = {};                                                                                              // 64
  this.mergedData = deepCopy(fields);                                                                          // 65
  this.children = {};                                                                                          // 66
  var self = this;                                                                                             // 67
  _.each(fields, function(val, key) {                                                                          // 68
    self.data[key] = self.data[key] || {};                                                                     // 69
    self.data[key][dependencyCursorId] = deepCopy(val);                                                        // 70
  });                                                                                                          // 71
}                                                                                                              // 72
CollectionItem.prototype.updateFromData = function(fields) {                                                   // 73
  var res = {};                                                                                                // 74
  var merged = this.mergedData;                                                                                // 75
  var self = this;                                                                                             // 76
  for (var key in fields) {                                                                                    // 77
    var cur = undefined;                                                                                       // 78
    _.each(self.data[key], (function(value) {                                                                  // 79
      cur = _.extend(deepCopy(value), cur);                                                                    // 80
    }));                                                                                                       // 81
    res[key] = cur;                                                                                            // 82
    if (_.isUndefined(cur)) {                                                                                  // 83
      delete merged[key];                                                                                      // 84
    } else {                                                                                                   // 85
      merged[key] = cur;                                                                                       // 86
    }                                                                                                          // 87
  };                                                                                                           // 88
  this.collection.publication.changed(this.collection.name, this.id, res);                                     // 89
}                                                                                                              // 90
CollectionItem.prototype.updateChildren = function(fields, removeAll) {                                        // 91
  var self = this;                                                                                             // 92
  var update = {};                                                                                             // 93
  for (var key in fields) {                                                                                    // 94
    _.each(self.collection.relations[key], function(dep) {                                                     // 95
      update[dep.id] = dep;                                                                                    // 96
    });                                                                                                        // 97
  };                                                                                                           // 98
  _.each(update, function(dep) {                                                                               // 99
    var toRemove = [];                                                                                         // 100
    if (dep.id in self.children) {                                                                             // 101
      self.children[dep.id].forEach(function(x) {                                                              // 102
        toRemove = toRemove.concat(x.getActiveItems());                                                        // 103
        x.stop();                                                                                              // 104
      });                                                                                                      // 105
    }                                                                                                          // 106
                                                                                                               // 107
    if (!removeAll) {                                                                                          // 108
      var context = new CallbacksWrapper(self.collection.publication.getCollectionByName);                     // 109
      var cursors = dep.callback.apply(context, [self.mergedData]);                                            // 110
      var wrappers = getWrappersFromCallbackResult(self.collection.publication.getCollectionByName, cursors);  // 111
      wrappers.push(context);                                                                                  // 112
      self.children[dep.id] = wrappers;                                                                        // 113
    } else {                                                                                                   // 114
      delete self.children[dep.id];                                                                            // 115
    }                                                                                                          // 116
    toRemove.forEach(function(args) {                                                                          // 117
      args[0].smartRemoved(args[1], args[2]);                                                                  // 118
    });                                                                                                        // 119
  });                                                                                                          // 120
}                                                                                                              // 121
                                                                                                               // 122
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/mrt:smart-publish/wrappers.js                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
SingleCollectionCallbacksWrapper = function(collection) {                                                      // 1
  this.activeItems = {};                                                                                       // 2
  this.collection = collection;                                                                                // 3
  this.dependencyCursorId = Random.id();                                                                       // 4
  this.getActiveItems = function() {                                                                           // 5
    var result = [];                                                                                           // 6
    var self = this;                                                                                           // 7
    _.each(this.activeItems, function(realId, strId) { // #6: if we use ObjectID as a key only, it won't work with Meteor
      result.push([self.collection, self.dependencyCursorId, realId]);                                         // 9
    });                                                                                                        // 10
    return result;                                                                                             // 11
  }                                                                                                            // 12
  var self = this;                                                                                             // 13
  _.extend(this, {                                                                                             // 14
    added:   function(id, fields) {                                                                            // 15
      self.activeItems[id] = id; // #6: if we store ObjectID as a key only, it won't work with Meteor          // 16
      fields['_id'] = id;                                                                                      // 17
      collection.smartAdded  (self.dependencyCursorId, id, fields);                                            // 18
    },                                                                                                         // 19
    changed: function(id, fields) {                                                                            // 20
      collection.smartChanged(self.dependencyCursorId, id, fields);                                            // 21
    },                                                                                                         // 22
    removed: function(id) {                                                                                    // 23
      delete self.activeItems[id];                                                                             // 24
      collection.smartRemoved(self.dependencyCursorId, id);                                                    // 25
    },                                                                                                         // 26
  });                                                                                                          // 27
};                                                                                                             // 28
                                                                                                               // 29
CursorWrapper = function(cursor, collection) {                                                                 // 30
  SingleCollectionCallbacksWrapper.call(this, collection);                                                     // 31
  this.observer = cursor.observeChanges(this);                                                                 // 32
  this.stop = function() {                                                                                     // 33
    this.observer.stop();                                                                                      // 34
  }                                                                                                            // 35
};                                                                                                             // 36
CursorWrapper.prototype = Object.create(SingleCollectionCallbacksWrapper.prototype);                           // 37
                                                                                                               // 38
CallbacksWrapper = function(getCollectionByName) {                                                             // 39
  var collectionWrappers = {};                                                                                 // 40
  this.added = function(name, id, fields) {                                                                    // 41
    collectionWrappers[name] = collectionWrappers[name] || new SingleCollectionCallbacksWrapper(getCollectionByName(name));
    collectionWrappers[name].added(id, fields);                                                                // 43
  };                                                                                                           // 44
  this.changed = function(name, id, fields) {                                                                  // 45
    collectionWrappers[name].changed(id, fields);                                                              // 46
  };                                                                                                           // 47
  this.removed = function(name, id) {                                                                          // 48
    collectionWrappers[name].removed(id);                                                                      // 49
  };                                                                                                           // 50
  this.getActiveItems = function() {                                                                           // 51
    var result = [];                                                                                           // 52
    _.each(collectionWrappers, function(wrapper, name) {                                                       // 53
      result = result.concat(wrapper.getActiveItems());                                                        // 54
    });                                                                                                        // 55
    return result;                                                                                             // 56
  }                                                                                                            // 57
  this.onStopCallbacks = [];                                                                                   // 58
  this.onStop = function(callback) {                                                                           // 59
    this.onStopCallbacks.push(callback);                                                                       // 60
  }                                                                                                            // 61
  this.stop = function() {                                                                                     // 62
    _.each(this.onStopCallbacks, function(callback) {                                                          // 63
      callback();                                                                                              // 64
    });                                                                                                        // 65
  }                                                                                                            // 66
};                                                                                                             // 67
                                                                                                               // 68
getWrappersFromCallbackResult = function(getCollectionByName, cursors) {                                       // 69
  if (!cursors) cursors = [];                                                                                  // 70
  if (isCursor(cursors)) cursors = [cursors];                                                                  // 71
  if (!_.isArray(cursors)) {                                                                                   // 72
    throw new Meteor.Error("Smart-publish callback function can only return a Cursor or an array of Cursors"); // 73
  }                                                                                                            // 74
  if (!_.every(cursors, isCursor)) {                                                                           // 75
    throw new Meteor.Error("Smart-publish callback function returned an array of non-Cursors");                // 76
  }                                                                                                            // 77
                                                                                                               // 78
  var wrappers = [];                                                                                           // 79
  _.each(cursors, function(c) {                                                                                // 80
    wrappers.push(new CursorWrapper(c, getCollectionByName(getCursorCollectionName(c))));                      // 81
  });                                                                                                          // 82
  return wrappers;                                                                                             // 83
}                                                                                                              // 84
                                                                                                               // 85
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/mrt:smart-publish/smart-publish.js                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Meteor.smartPublish = function(name, callback) {                                                               // 1
  Meteor.publish(name, function() {                                                                            // 2
    var publication = this;                                                                                    // 3
    var collections = {};                                                                                      // 4
    function getCollectionByName(name) {                                                                       // 5
      return collections[name] = collections[name] || new Collection(name);                                    // 6
    }                                                                                                          // 7
    publication.getCollectionByName = getCollectionByName;                                                     // 8
                                                                                                               // 9
    function Collection() {                                                                                    // 10
      BaseCollection.apply(this, arguments);                                                                   // 11
    }                                                                                                          // 12
    Collection.prototype = Object.create(BaseCollection.prototype);                                            // 13
    Collection.prototype.publication = publication;                                                            // 14
                                                                                                               // 15
    publication.addDependency = function(name, fields, callback) {                                             // 16
      if (!_.isArray(fields)) fields = [fields];                                                               // 17
      var relations = getCollectionByName(name).relations;                                                     // 18
      var dep = new Dependency(callback);                                                                      // 19
      fields.forEach(function(field) {                                                                         // 20
        if (field.indexOf(".") != -1) { // See #8                                                              // 21
          field = field.substr(0, field.indexOf("."));                                                         // 22
        }                                                                                                      // 23
        relations[field] = relations[field] || [];                                                             // 24
        relations[field].push(dep);                                                                            // 25
      });                                                                                                      // 26
    }                                                                                                          // 27
                                                                                                               // 28
    var context = Object.create(publication);                                                                  // 29
    _.extend(context, new CallbacksWrapper(getCollectionByName));                                              // 30
    context.ready = undefined;                                                                                 // 31
    var cursors = callback.apply(context, arguments);                                                          // 32
    var wrappers = getWrappersFromCallbackResult(getCollectionByName, cursors);                                // 33
    wrappers.push(context);                                                                                    // 34
    this.ready();                                                                                              // 35
    this.onStop(function() {                                                                                   // 36
      _.forEach(wrappers, function(x) {                                                                        // 37
        x.stop();                                                                                              // 38
      });                                                                                                      // 39
    });                                                                                                        // 40
  });                                                                                                          // 41
}                                                                                                              // 42
                                                                                                               // 43
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:smart-publish'] = {};

})();

//# sourceMappingURL=mrt_smart-publish.js.map
