/* Imports for global scope */

Router = Package['iron:router'].Router;
RouteController = Package['iron:router'].RouteController;
Alerts = Package['mrt:bootstrap-alerts'].Alerts;
Fake = Package['anti:fake'].Fake;
ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
moment = Package['momentjs:moment'].moment;
Spiderable = Package.spiderable.Spiderable;
FastRender = Package['meteorhacks:fast-render'].FastRender;
sitemaps = Package['gadicohen:sitemaps'].sitemaps;
Meteor = Package.meteor.Meteor;
WebApp = Package.webapp.WebApp;
main = Package.webapp.main;
WebAppInternals = Package.webapp.WebAppInternals;
Log = Package.logging.Log;
Tracker = Package.deps.Tracker;
Deps = Package.deps.Deps;
DDP = Package.livedata.DDP;
DDPServer = Package.livedata.DDPServer;
MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Blaze = Package.ui.Blaze;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
Spacebars = Package.spacebars.Spacebars;
check = Package.check.check;
Match = Package.check.Match;
_ = Package.underscore._;
Random = Package.random.Random;
EJSON = Package.ejson.EJSON;
Iron = Package['iron:core'].Iron;
SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
MongoObject = Package['aldeed:simple-schema'].MongoObject;
Accounts = Package['accounts-base'].Accounts;
FS = Package['cfs:base-package'].FS;
HTML = Package.htmljs.HTML;

