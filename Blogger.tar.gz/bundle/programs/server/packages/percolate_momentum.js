(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['percolate:momentum'] = {};

})();

//# sourceMappingURL=percolate_momentum.js.map
