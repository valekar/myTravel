(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;

/* Package-scope variables */
var __coffeescriptShare;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/todda00:friendly-slugs/slugs.coffee.js                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Mongo, slugify;

if (typeof Mongo === "undefined") {
  Mongo = {};
  Mongo.Collection = Meteor.Collection;
}

Mongo.Collection.prototype.friendlySlugs = function(options) {
  var collection, fsDebug, runSlug;
  if (options == null) {
    options = {};
  }
  collection = this;
  if (!_.isArray(options)) {
    options = [options];
  }
  _.each(options, function(opts) {
    var defaults, fields;
    if (_.isString(opts)) {
      opts = {
        slugFrom: opts
      };
    }
    defaults = {
      slugFrom: 'name',
      slugField: 'slug',
      distinct: true,
      updateSlug: true,
      createOnUpdate: true,
      debug: false
    };
    _.defaults(opts, defaults);
    fields = {
      slugFrom: String,
      slugField: String,
      distinct: Boolean,
      updateSlug: Boolean,
      createOnUpdate: Boolean,
      debug: Boolean
    };
    check(opts, Match.ObjectIncluding(fields));
    collection.before.insert(function(userId, doc) {
      runSlug(doc, opts);
    });
    collection.before.update(function(userId, doc, fieldNames, modifier, options) {
      var slugFromChanged;
      if (options.multi) {
        fsDebug(opts, "multi doc update attempted, can't update slugs this way, leaving.");
        return true;
      }
      modifier = modifier || {};
      modifier.$set = modifier.$set || {};
      if ((doc[opts.slugFrom] == null) && (modifier.$set[opts.slugFrom] == null)) {
        return true;
      }
      slugFromChanged = false;
      if (modifier.$set[opts.slugFrom] != null) {
        if (doc[opts.slugFrom] !== modifier.$set[opts.slugFrom]) {
          slugFromChanged = true;
        }
      }
      fsDebug(opts, slugFromChanged, 'slugFromChanged');
      if ((doc[opts.slugField] == null) && opts.createOnUpdate) {
        fsDebug(opts, 'Update: Slug Field is missing and createOnUpdate is set to true');
        if (slugFromChanged) {
          fsDebug(opts, 'slugFrom field has changed, runSlug with modifier');
          runSlug(doc, opts, modifier);
        } else {
          fsDebug(opts, 'runSlug to create');
          runSlug(doc, opts, modifier, true);
          return true;
        }
      } else {
        if (opts.updateSlug === false) {
          fsDebug(opts, 'updateSlug is false, nothing to do.');
          return true;
        }
        if (doc[opts.slugFrom] === modifier.$set[opts.slugFrom]) {
          fsDebug(opts, 'slugFrom field has not changed, nothing to do.');
          return true;
        }
        runSlug(doc, opts, modifier);
        return true;
      }
      return true;
    });
  });
  runSlug = function(doc, opts, modifier, create) {
    var baseField, fieldSelector, finalSlug, from, index, indexField, limitSelector, result, slugBase, sortSelector;
    if (modifier == null) {
      modifier = false;
    }
    if (create == null) {
      create = false;
    }
    fsDebug(opts, 'Begin runSlug');
    fsDebug(opts, opts, 'Options');
    fsDebug(opts, modifier, 'Modifier');
    fsDebug(opts, create, 'Create');
    from = create || !modifier ? doc[opts.slugFrom] : modifier.$set[opts.slugFrom];
    fsDebug(opts, from, 'Slugging From');
    slugBase = slugify(from);
    if (!slugBase) {
      return false;
    }
    fsDebug(opts, slugBase, 'SlugBase');
    if (opts.distinct) {
      baseField = "friendlySlugs." + opts.slugField + ".base";
      indexField = "friendlySlugs." + opts.slugField + ".index";
      fieldSelector = {};
      fieldSelector[baseField] = slugBase;
      sortSelector = {};
      sortSelector[indexField] = -1;
      limitSelector = {};
      limitSelector[indexField] = 1;
      result = collection.findOne(fieldSelector, {
        sort: sortSelector,
        fields: limitSelector,
        limit: 1
      });
      fsDebug(opts, result, 'Highest indexed base found');
      if ((result == null) || (result.friendlySlugs == null) || (result.friendlySlugs[opts.slugField] == null) || (result.friendlySlugs[opts.slugField].index == null)) {
        index = 0;
      } else {
        index = result.friendlySlugs[opts.slugField].index + 1;
      }
      if (index === 0) {
        finalSlug = slugBase;
      } else {
        finalSlug = slugBase + '-' + index;
      }
    } else {
      index = false;
      finalSlug = slugBase;
    }
    fsDebug(opts, finalSlug, 'finalSlug');
    if (modifier || create) {
      fsDebug(opts, 'Set to modify or create slug on update');
      modifier = modifier || {};
      modifier.$set = modifier.$set || {};
      modifier.$set.friendlySlugs = doc.friendlySlugs || {};
      modifier.$set.friendlySlugs[opts.slugField] = modifier.$set.friendlySlugs[opts.slugField] || {};
      modifier.$set.friendlySlugs[opts.slugField].base = slugBase;
      modifier.$set.friendlySlugs[opts.slugField].index = index;
      modifier.$set[opts.slugField] = finalSlug;
      fsDebug(opts, modifier, 'Final Modifier');
    } else {
      fsDebug(opts, 'Set to update');
      doc.friendlySlugs = doc.friendlySlugs || {};
      doc.friendlySlugs[opts.slugField] = doc.friendlySlugs[opts.slugField] || {};
      doc.friendlySlugs[opts.slugField].base = slugBase;
      doc.friendlySlugs[opts.slugField].index = index;
      doc[opts.slugField] = finalSlug;
      fsDebug(opts, doc, 'Final Doc');
    }
    return true;
  };
  return fsDebug = function(opts, item, label) {
    if (label == null) {
      label = '';
    }
    if (!opts.debug) {
      return;
    }
    if (typeof item === 'object') {
      console.log("friendlySlugs DEBUG: " + label + '↓');
      return console.log(item);
    } else {
      return console.log("friendlySlugs DEBUG: " + label + '= ' + item);
    }
  };
};

slugify = function(text) {
  if (text == null) {
    return false;
  }
  if (text.length < 1) {
    return false;
  }
  return text.toString().toLowerCase().replace(/\s+/g, '-').replace(/[^\w\-]+/g, '').replace(/\-\-+/g, '-').replace(/^-+/, '').replace(/-+$/, '');
};
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['todda00:friendly-slugs'] = {};

})();

//# sourceMappingURL=todda00_friendly-slugs.js.map
