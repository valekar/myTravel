(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Alerts;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:bootstrap-alerts'] = {
  Alerts: Alerts
};

})();

//# sourceMappingURL=mrt_bootstrap-alerts.js.map
