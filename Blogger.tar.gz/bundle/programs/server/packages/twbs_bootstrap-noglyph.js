(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['twbs:bootstrap-noglyph'] = {};

})();

//# sourceMappingURL=twbs_bootstrap-noglyph.js.map
